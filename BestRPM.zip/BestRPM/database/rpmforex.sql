--
-- PostgreSQL database dump
--

\restrict jusA3oDLIhCBv0zg6lkjYSz3cipvyUNlOfUzCJdFkzGvKEf1O6LmuA0DwlAY0Lt

-- Dumped from database version 17.11 (7d7ea2a)
-- Dumped by pg_dump version 18.6 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AdminRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AdminRole" AS ENUM (
    'SUPER_ADMIN',
    'BLOG_MANAGER'
);


--
-- Name: AffiliateStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AffiliateStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'SUSPENDED'
);


--
-- Name: DiscountType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DiscountType" AS ENUM (
    'FIXED',
    'PERCENTAGE'
);


--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'COMPLETE'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'STRIPE',
    'BITCOIN'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED',
    'REFUNDED'
);


--
-- Name: PayoutStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PayoutStatus" AS ENUM (
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED'
);


--
-- Name: PostStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PostStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'ARCHIVED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AdminUser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AdminUser" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    role public."AdminRole" DEFAULT 'BLOG_MANAGER'::public."AdminRole" NOT NULL
);


--
-- Name: Affiliate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Affiliate" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    "paymentEmail" text,
    "paymentMethod" text,
    "referralCode" text NOT NULL,
    "commissionRate" numeric(5,2) DEFAULT 20 NOT NULL,
    status public."AffiliateStatus" DEFAULT 'PENDING'::public."AffiliateStatus" NOT NULL,
    "totalClicks" integer DEFAULT 0 NOT NULL,
    "totalOrders" integer DEFAULT 0 NOT NULL,
    "totalEarnings" numeric(10,2) DEFAULT 0 NOT NULL,
    "pendingEarnings" numeric(10,2) DEFAULT 0 NOT NULL,
    "paidEarnings" numeric(10,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "resetToken" text,
    "resetTokenExpiry" timestamp(3) without time zone
);


--
-- Name: BlogCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BlogCategory" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: BlogPost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BlogPost" (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text NOT NULL,
    excerpt text,
    "featuredImage" text,
    status public."PostStatus" DEFAULT 'DRAFT'::public."PostStatus" NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "categoryId" text,
    "metaTitle" text,
    "metaDescription" text,
    "ogImage" text,
    "canonicalUrl" text,
    "readingTime" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ContactSubmission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ContactSubmission" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    message text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Coupon; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Coupon" (
    id text NOT NULL,
    code text NOT NULL,
    description text,
    "discountType" public."DiscountType" NOT NULL,
    "discountValue" numeric(10,2) NOT NULL,
    "maxUses" integer,
    "usedCount" integer DEFAULT 0 NOT NULL,
    "minOrderAmount" numeric(10,2),
    active boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    "orderRef" text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    "brokerOption" text NOT NULL,
    "brokerLabel" text NOT NULL,
    price numeric(10,2) NOT NULL,
    "paymentMethod" public."PaymentMethod" NOT NULL,
    "paymentStatus" public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "stripeSessionId" text,
    "stripePaymentId" text,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "shippedAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    notes text,
    "stripeReceiptUrl" text,
    "affiliateCode" text,
    "discountAmount" numeric(10,2),
    "discountCode" text,
    "paidAmount" numeric(10,2)
);


--
-- Name: Payout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payout" (
    id text NOT NULL,
    "affiliateId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    method text NOT NULL,
    reference text,
    status public."PayoutStatus" DEFAULT 'PENDING'::public."PayoutStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "processedAt" timestamp(3) without time zone
);


--
-- Name: Referral; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Referral" (
    id text NOT NULL,
    "affiliateId" text NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "landingPage" text,
    "orderId" text,
    converted boolean DEFAULT false NOT NULL,
    commission numeric(10,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "convertedAt" timestamp(3) without time zone
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AdminUser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AdminUser" (id, email, password, name, "createdAt", "updatedAt", "isActive", role) FROM stdin;
cmjd5aaix0000v2ovorfxig74	admin@rpmtrading.co.uk	$2b$12$k0B1tBLcKmSeCf28.4sz0uH1lTVd9dIlE4MkGpwCsZrUvB/AmhlLi	Admin	2025-12-19 17:30:13.065	2025-12-19 17:30:13.065	t	SUPER_ADMIN
cmmckfckr0000lmovj7wjgxid	ribbit@pinkfrog.studio	$2b$12$Ms9FEc6S82781ptk97.r3OsUjzTXs8RU8WtwUKrccKzey6jk25zVG	Sam	2026-03-04 21:45:24.074	2026-04-05 22:11:46.813	t	SUPER_ADMIN
cmnmbisfk000004kzyhc1lduu	christophermharris@gmail.com	$2b$12$7AG/G3egXEVB9R4gPE7/wOh1xmuWiMHunRtRfxE/WQ9Dg2wF2lIka	Christopher Harris	2026-04-05 22:13:32.143	2026-04-05 22:13:32.143	t	BLOG_MANAGER
\.


--
-- Data for Name: Affiliate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Affiliate" (id, email, password, name, "paymentEmail", "paymentMethod", "referralCode", "commissionRate", status, "totalClicks", "totalOrders", "totalEarnings", "pendingEarnings", "paidEarnings", "createdAt", "updatedAt", "resetToken", "resetTokenExpiry") FROM stdin;
cmjflxpj9000004l4h5pljlug	ribbit@pinkfrog.studio	$2b$12$E3QCbEb3bS0s0Mg01qQOYueRCDZ1sHqLUCtOW7zKWz7.wd3AsGZYe	Samuel Hembury	ribbit@pinkfrog.studio	bank	XKCNLOM3	20.00	APPROVED	1	0	0.00	0.00	0.00	2025-12-21 10:51:51.813	2025-12-21 10:54:24.277	\N	\N
cmm68bqnv000004lam0bh09qa	precision_trading@hotmail.com	$2b$12$7iO4ar4xk5g4ZB1ISX56xuBLdEnXY.pOdg5OGzvE06T6m40pppGaO	Aidan Mclean	aidanmclean@hotmail.co.uk	bank	P3SMWIAX	20.00	SUSPENDED	0	0	0.00	0.00	0.00	2026-02-28 11:20:03.259	2026-07-14 22:20:03.82	\N	\N
cmn4h5on1000004jsf73lb361	info@bestforexeas.com	$2b$12$l2KYYEKM9LEqacrUPFH48e2leB1kJ5dA30fi51ayCZhJCxzOCOGVG	Michael Sommer	bestforexeas2014@gmail.com	paypal	FQOVGC2Y	20.00	SUSPENDED	0	0	0.00	0.00	0.00	2026-03-24 10:31:27.229	2026-07-14 22:20:10.731	\N	\N
cmk5sjfp8000004jme9stvja1	petko.alexandrov@gmail.com	$2b$12$svGyWk3gp0cHYEn.C111gOdfK8ln9xnHG7EvVF5hblQUHA7d.jrM.	Petko Aleksandrov	petko.alexandrov@gmail.com	bank	ZPW856QJ	50.00	SUSPENDED	19	0	0.00	0.00	0.00	2026-01-08 18:38:43.772	2026-07-14 22:20:18.303	5ba311502311b479351b1044fd083d0341fbbb37aabd56337c9d016911d38df6	2026-06-16 15:16:10.454
cmjwperxo000004l7dg2w83lo	marrofinho@gmail.com	$2b$12$WGUaGYk5Kom4QGr00RLAIewAxBB5gwgtNVV5JFbVZ6t/CXDwd84xK	Micael Stefan Salewski 	marrofinho@gmail.com	crypto	6ARC6ZOP	20.00	SUSPENDED	0	0	0.00	0.00	0.00	2026-01-02 10:01:11.916	2026-07-14 22:20:20.076	\N	\N
\.


--
-- Data for Name: BlogCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BlogCategory" (id, name, slug, description, "createdAt", "updatedAt") FROM stdin;
cmoh3x7qp000104l2h4x69rkr	Gold Trading Bot	gold-trading-bot	Articles that discuss automated gold trading bot.	2026-04-27 11:21:39.697	2026-04-27 11:21:39.697
cmoh5239h000304l2xozujxdr	RPM Forex Gold Bot	rpm-forex-gold-bot	Understanding how the RPM Forex Gold Bot works.	2026-04-27 11:53:26.789	2026-04-27 11:53:26.789
\.


--
-- Data for Name: BlogPost; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BlogPost" (id, title, slug, content, excerpt, "featuredImage", status, "publishedAt", "categoryId", "metaTitle", "metaDescription", "ogImage", "canonicalUrl", "readingTime", "createdAt", "updatedAt") FROM stdin;
cmoh3vkpz000004l26xi8uejb	What is an Automated Gold Trading Bot?	automated-gold-trading-bot	<p>In the fast-paced world of Forex trading, many investors are turning to automated systems to capitalize on 24/5 market opportunities. One of the more popular specialized tools currently available is the automated gold trading bot from <a target="_blank" rel="noopener noreferrer" href="https://rpmforex.com/"><u>RPM Forex</u></a> designed specifically for the XAU/USD (Gold) pair.</p><p>Investing in the gold market offers immense potential. Utilizing an automated bot allows you to capitalize on gold’s liquidity and price swings with precision execution that far exceeds human speed. By removing emotional bias—the leading cause of trading losses—and ensuring strict adherence to risk management round-the-clock, a gold bot transforms a complex market into a consistent, systematic investment vehicle.</p><p>Gold trading bots, also known as Expert Advisors or EAs, are automated software programs for <a target="_blank" rel="noopener noreferrer" href="https://en.wikipedia.org/wiki/MetaTrader_4"><u>MetaTrader 4</u></a> designed to executive XAU/USD trades by analyzing market volatility, trends, and support/resistance levels. Popular, specialized options include RPM Forex, Gold Scalper Pro, EA Gold Stuff, and Gold Reaper, which often utilize trend-following strategies to manage gold's high volatility.</p><p>RPM Forex’s Gold Bot uses its own algorithm to deliver results that can generate a <strong>monthly</strong> <strong>return</strong> of <strong>7.30%</strong> or more. View <a target="_blank" rel="noopener noreferrer" href="https://rpmforex.com/results"><u>RPM Forex Gold Bot performance for 2025</u></a> to see how it did last year.</p><p>If you’re interested in getting an automated gold trading bot, the first and most crucial step is ensuring you are on the legitimate platform. Navigate to <a target="_blank" rel="noopener noreferrer" href="http://rpmforex.com">rpmforex.com</a>. Take a moment to review our performance statistics and the specific requirements for the Gold Bot to ensure it aligns with your investment goals and risk tolerance.</p>	In the fast-paced world of Forex trading, many investors are turning to automated systems to capitalize on 24/5 market opportunities. One of the more popular...	https://gtcc2bffwnrabgqi.public.blob.vercel-storage.com/blog/1777289126530-gold-currency.jpg	PUBLISHED	2026-04-27 11:25:53.127	cmoh3x7qp000104l2h4x69rkr	\N	RPM Forex explains what an automated gold trading bot is. and how investing in the gold market offers enormous potential to investors.	\N	\N	2	2026-04-27 11:20:23.126	2026-04-27 11:25:53.129
cmoilf31t000004l77kmw3nq4	RPM Forex Launches Advanced Trading Platform and Introduces Revolutionary Gold Trading Bot	rpm-forex-launches-gold-trading-bot	<p style="text-align:center"><em>New AI-powered solution aims to deliver consistent returns through automated, precision-driven trading</em></p><p><strong>LONDON, 29 APRIL 2026</strong> — RPM Forex, a newly established software development firm specializing in financial technology, today announced the official launch of its website, <a target="_blank" rel="noopener noreferrer" href="http://RPMForex.com"><u>RPMForex.com</u></a>, alongside its flagship innovation, the RPM Forex Gold Bot—an advanced automated trading solution designed to help traders achieve consistent returns in the dynamic forex market.</p><p>The RPM Forex Gold Bot leverages cutting-edge algorithmic technology to analyze global market conditions in real time. Operating 24/7, the bot continuously scans price movements, identifies high-probability trading opportunities, and executes trades with precision and discipline—removing emotional decision-making from the trading process.</p><p>The RPM Forex Gold Bot is now available starting at £495, and can be purchased directly via <a target="_blank" rel="noopener noreferrer" href="https://rpmforex.com/buy"><u>rpmforex.com/buy</u></a></p><p>“Our mission at RPM Forex is to empower traders with intelligent tools that simplify the complexities of the forex market,” said RPM Forex Trading CEO Guy Shotton. “The RPM Forex Gold Bot represents a major step forward in automated trading, combining speed, accuracy, and consistency to help users optimize their trading performance.”</p><p>Key features of the RPM Forex Gold Bot include:</p><ul><li><p><strong>24/5 Market Analysis:</strong> Continuous monitoring of market trends and price movements</p></li><li><p><strong>Automated Trade Execution:</strong> Fast, disciplined order placement without human intervention</p></li><li><p><strong>Advanced Algorithmic Strategies:</strong> Designed to identify and act on high-probability setups</p></li><li><p><strong>Consistency-Focused Performance:</strong> Built to reduce emotional trading and improve long-term results</p></li></ul><p>With the launch of <a target="_blank" rel="noopener noreferrer" href="http://RPMForex.com">RPMForex.com</a>, users can now explore the platform, learn more about the technology behind the bot, and gain access to tools designed to support both new and experienced traders.</p><p>As global interest in automated trading continues to grow, RPM Forex aims to position itself at the forefront of innovation by delivering reliable, user-friendly solutions tailored to modern trading needs.</p><p>For more information, visit <a target="_blank" rel="noopener noreferrer" href="http://RPMForex.com"><u>RPMForex.com</u></a> or purchase the bot at <a target="_blank" rel="noopener noreferrer" href="https://rpmforex.com/buy"><u>rpmforex.com/buy</u></a>.</p><p style="text-align:left"><strong>About RPM Forex<br /><br /></strong>RPM Forex is a software development company focused on creating advanced trading technologies for the forex market. By combining algorithmic intelligence with user-centric design, RPM Forex develops solutions that help traders achieve greater efficiency, consistency, and performance. Headquartered in the United Kingdom, RPM Forex software is available worldwide via its website at <a target="_blank" rel="noopener noreferrer" href="http://RPMForex.com"><u>RPMForex.com</u></a>.<br /><br /><em>Keep in mind that investing involves risk. The value of your investment will fluctuate over time, and you may gain or lose money. <br /><br />RPM Forex does not provide legal or tax advice. The information herein is general in nature and should not be considered legal or tax advice. Consult an attorney or tax professional regarding your specific situation. <br /><br />Views expressed are as of the date indicated, based on the information available at that time, and may change based on market or other conditions. Unless otherwise noted, the opinions provided are those of the speaker or author and not necessarily those of RPM Forex or its affiliates.</em></p>	RPM Forex announces the launch of its website alongside the RPM Forex Gold Bot, designed to help traders achieve consistent returns in the dynamic forex market.	https://gtcc2bffwnrabgqi.public.blob.vercel-storage.com/blog/1777460069331-gold-bars.jpg	PUBLISHED	2026-04-29 10:54:00	cmoh5239h000304l2xozujxdr	RPM Forex Introduces Revolutionary Gold Trading Bot	RPM Forex announces the launch of its website alongside the RPM Forex Gold Bot, designed to help traders achieve consistent returns in the dynamic forex market.	\N	\N	3	2026-04-28 12:19:12.993	2026-04-29 11:12:38.983
cmoh4ixqv000204l2b4ks7yvb	How to Use the RPM Forex Gold Bot for 24/5 Trading	rpm-forex-gold-bot-for-trading	<p>Imagine capturing the explosive price movements of the gold market without ever having to stare at a chart or second-guess a trade. In the high-stakes world of XAUUSD trading, speed and discipline are everything—and that’s exactly where automation changes the game. By leveraging a specialized bot, you can strip away the emotional stress of manual trading and execute precise strategies 24 hours a day. <br /><br />Whether you’re a seasoned investor or a complete beginner, this article will walk you through the entire process of getting the RPM Forex Gold Bot up, running, and ready to trade for you.</p><h2>How to Use RPM Forex for Gold Trading</h2><p></p><h4><strong>Step 1: </strong><a target="_blank" rel="noopener noreferrer" href="https://rpmforex.com/buy"><strong><u>Purchase RPM Forex Gold Bot</u></strong></a></h4><p><br />Pricing for RPM Forex is £495 when you use one of our recommended brokers. That’s only $668 as of April 26th, 2026.</p><p>Once you select a plan, you will be directed to a checkout page.</p><ol><li><p><strong>Enter your details:</strong> Provide a valid email address, as this is where your license key and details will be sent.</p></li><li><p><strong>Select a payment method:</strong> RPM Forex’s platform accepts credit and debit cards as well as Bitcoin.</p></li><li><p><strong>Confirm purchase:</strong> After payment is processed, check your inbox for a confirmation email..</p></li></ol><p>In your confirmation email from RPM Forex, you’ll see two attachments. Go ahead and download both of these files (library.mt4 and RPMForexGoldBot.mt4) to your ‘Downloads’ section on your computer.</p><p>The confirmation email also mentions that you’ll need to reply to RPM Forex by email with your MT4 account number to receive the license key for RPM Forex. We’ll come back to this after you complete Step 2.</p><p></p><h4><strong>Step 2: </strong><a target="_blank" rel="noopener noreferrer" href="https://rpmforex.com/brokers"><strong><u>Open an account with a MetaTrader 4 Broker</u></strong></a></h4><p><br />To use the Gold Bot, you need a brokerage account that supports the <strong>MetaTrader 4 (MT4)</strong> platform, which is the industry standard for Expert Advisors (EAs).</p><p>You’ll need to open an account with a minimum of $100, which is the equivalent of 10,000 cents.</p><p>Choose a broker that supports Cent accounts such as any of the following <a target="_blank" rel="noopener noreferrer" href="https://rpmforex.com/brokers"><u>broker accounts recommended by RPM Forex &gt;</u></a></p><p>Once you’ve signed up for a broker, copy your account number and account password from the broker account. </p><p>Go back to the confirmation email that you received from RPM Forex, and reply to that email with your MT4 Broker account number so you can get your RPM Forex Gold Bot license number.</p><p>You’ll need the broker account number later too when you set up the RPM Forex Gold Bot in Step 7.</p><p></p><h4><strong>Step 3: Download the MT4 software to your computer</strong></h4><p><br />In your MT4 broker account that you set up in the last step, you’ll find a link to download MetaTrader 4 software. Go ahead and download this to your computer.<br /><br /></p><h4><strong>Step 4: </strong><a target="_blank" rel="noopener noreferrer" href="https://chocoping.com/processing/aff.php?aff=180&amp;gocart=true"><strong><u>Register for a VPS Hosting account</u></strong><br /></a></h4><p>To keep the bot running 24/7 without needing your home computer to stay on, we recommend  hosting your MT4 on a Virtual Private Server (VPS). A VPS is a virtual machine that hosts all the software and data required to run an application.</p><p>Here’s the VPS that RPM Forex recommends: <a target="_blank" rel="noopener noreferrer" href="https://chocoping.com/processing/aff.php?aff=180&amp;gocart=true"><u>Chocoping &gt;</u></a></p><p>Chocoping offers several options for a cheap forex VPS — each determined by the RAM size. For the purpose of running one instance of the RPM Forex Gold Bot, Chocoping’s Cheapy VPS #1 is sufficient.</p><p>After you’ve ordered the VPS from <a target="_blank" rel="noopener noreferrer" href="https://chocoping.com/processing/aff.php?aff=180&amp;gocart=true"><u>Chocoping</u></a>, you’ll receive a confirmation email from Chocoping that includes the computer IP and password. </p><p></p><h4><strong>Step 5: Install the MT4 software on your virtual machine</strong></h4><p><br />With your RPM Forex license number, broker account information plus your VPS hosting account registered, you’re just a few steps from running the RPM Forex Gold Bot.</p><p>On your computer that’s running Microsoft Windows, search for the application named Remote Desktop Connection, and open that.</p><p>In the ‘Computer’ field, enter the IP address from the Chocoping email confirmation. In the ‘Username’ field, enter “Administrator”.</p><p>Next, click ‘Connect’ and you’ll be prompted to enter your password (again, from the Chocoping email confirmation email).</p><p>You’ll then be logged into your VPS. After it finishes logging in, go ahead and go to the ‘Downloads’ section of <strong>your</strong> physical computer and right click on the MT4 software you downloaded earlier and select ‘Copy’ to copy the file.</p><p>Then, click on the ‘Downloads’ section of your virtual computer. Then paste the MT4 software into your Downloads folder.</p><p>After it finishes copying the file to your virtual server, double click on the file and it’ll then install the software on your virtual machine.</p><p></p><h4><strong>Step 6: Install the RPM Forex Gold Bot and library file on your virtual machine</strong></h4><p><br />After the MT4 terminal is installed (see Step 5 above), you’ll be prompted to enter your login and password. Use the username and password from your broker account that you received in Step 2 above.</p><p>Minimize your MT4 terminal for a minute and go to the ‘Downloads’ section on your physical computer, and copy both the ‘RPMForexGoldBot.mt4’ file.</p><p>Return to your MT4 terminal, click ‘File’ and then select ‘Open Data Folder’. Open the MQL4 folder, and then select the ‘Experts’ folder.</p><p>Then paste your ‘RPMForexGoldBot.mt4’ file into that folder.</p><p>Subsequently, minimize your MT4 terminal, and select the ‘library.mt4’ file from your ‘Downloads’ section on your physical computer. Return to your virtual machine, and then click ‘File,’ “Open Data Folder,’ ‘MQL4’ and then the ‘Libraries’ folder.</p><p>Paste your ‘library.mt4’ into your folder.</p><p></p><h4><strong>Step 7: Final steps to get the RPM Forex Gold Bot working</strong></h4><p><br />Go ahead and close your MT4 terminal. After logging back in again to the MT4 terminal on your virtual machine, click on the ‘RPMForexGoldBot’ and then right-click to select the ‘Attach to chart’ option.</p><p>Under the ‘Expert Advisors’ section of the MT4 terminal, grab the RPMForexGoldBot file and drag it into your main window on the virtual machine.</p><p>Under the ‘Inputs’ folder, you’ll then enter your license key you received via email from RPM Forex (see Steps 1 and 2).</p><p>To understand what to input for the ‘Lots’ and ‘EquityProtection’ options, <a target="_blank" rel="noopener noreferrer" href="https://youtu.be/pvwN-MhkkVc?si=MDf598XYFpMZ8R2N&amp;t=860"><u>watch our video</u></a></p><p>And that's it. <strong>You’re ready to trade!</strong></p><p></p><p>To better understand how to start using the RPM Gold Forex Bot in your MT4 terminal, <a target="_blank" rel="noopener noreferrer" href="https://youtu.be/pvwN-MhkkVc?si=MDf598XYFpMZ8R2N&amp;t=860"><u>watch our helpful video</u></a> that walks you through all of the options and features.</p><p>The video also shows you the accounts we’ve set up for demonstration purposes to show you how effective the RPM Gold Forex Bot is. </p><p>If you need any help along the way to getting the RPM Forex Gold Bot installed or working, be sure to view our <a target="_blank" rel="noopener noreferrer" href="https://youtu.be/pvwN-MhkkVc?si=A6E7Y5yXyxOAlRD6">comprehensive step-by-step video</a>.<br /></p><h3><strong>Final Thoughts</strong></h3><p>The RPM Forex Gold Bot is a powerful tool for those looking to trade the volatility of the gold market. However, always remember that all trading involves risk. Start with a demo account or a small "cent" account to see how the bot behaves before committing significant capital.</p><p><strong>Ready to start?</strong> To begin your automated trading journey, head over to <a target="_blank" rel="noopener noreferrer" href="http://rpmforex.com/buy"><u>rpmforex.com/buy</u></a> </p>	Discover how to use RPM Forex Gold Bot that delivers impressive results for investors looking for an automated gold trading bot with advanced technology.	https://gtcc2bffwnrabgqi.public.blob.vercel-storage.com/blog/1777290140439-rpm-forex-logo.jpg	PUBLISHED	2026-04-27 12:15:13.643	cmoh5239h000304l2xozujxdr	\N	Discover how to use RPM Forex Gold Bot that delivers impressive results for investors looking for an automated gold trading bot with advanced technology.	\N	\N	6	2026-04-27 11:38:33.097	2026-04-27 12:15:13.643
\.


--
-- Data for Name: ContactSubmission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ContactSubmission" (id, name, email, phone, message, read, "createdAt") FROM stdin;
cmue1rs8l000004l94cpiv8cs	Sam Hembury	info@hemburycontracting.co.uk	07432829707	testing testing 123 - testing contact form submission	f	2026-09-23 11:56:22.58
cmuea1jdv000004jngzitb2na	Guy Shotton	charlieman798@gmail.com	01548434063	hi I am interested in fores	f	2026-09-23 15:47:54.594
\.


--
-- Data for Name: Coupon; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Coupon" (id, code, description, "discountType", "discountValue", "maxUses", "usedCount", "minOrderAmount", active, "expiresAt", "createdAt", "updatedAt") FROM stdin;
cmmckhl570000hpovx7zeazcr	SAVE10	10% general	PERCENTAGE	10.00	\N	1	\N	t	\N	2026-03-04 21:47:08.49	2026-03-04 21:50:29.162
cmmclm8tf000004kzegmyllrt	RPM10	\N	PERCENTAGE	10.00	\N	0	\N	t	\N	2026-03-04 22:18:45.411	2026-03-04 22:18:45.411
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Order" (id, "orderRef", name, email, phone, "brokerOption", "brokerLabel", price, "paymentMethod", "paymentStatus", "stripeSessionId", "stripePaymentId", status, "createdAt", "updatedAt", "paidAt", "shippedAt", "deliveredAt", notes, "stripeReceiptUrl", "affiliateCode", "discountAmount", "discountCode", "paidAmount") FROM stdin;
cmjndz1zt000004ibbait6xm2	RPM-MJNDZ1UI-AMIK	Claire Vessey	morganboat1@gmail.com	\N	our-brokers	Our Recommended Brokers	495.00	STRIPE	PENDING	cs_live_b1but0EPZuha3I6EAnkydBZCmZMfEJdPir12TVruOS2Cc9ZoL6xLW7gO8x	\N	PENDING	2025-12-26 21:31:07.096	2025-12-26 21:31:08.501	\N	\N	\N	\N	\N	\N	\N	\N	\N
cmjnswopz000004jv346yxotx	RPM-MJNSWOJT-AP8L	Claire Vessey	morganboat1@gmail.com	\N	our-brokers	Our Recommended Brokers	495.00	STRIPE	PAID	cs_live_b1SXLkSbCE8PR8kvvOoDmd5JOTKWkDNUeg8QKwdrs6AsqO2h7MYRR29Tr8	pi_3Sip8i2HuCkfXdFO1OgF0iS7	PENDING	2025-12-27 04:29:10.823	2025-12-29 23:57:40.606	2025-12-29 23:57:40.481	\N	\N	\N	https://pay.stripe.com/receipts/payment/CAcQARoXChVhY2N0XzFTZmxaazJIdUNrZlhkRk8o9KrMygYyBp-thyNptjosFkiEZI8xlVG_PnzuSDi8PawpfMH8m4AkCljmRwfl3PXt_QtGrPxKkEa97Ms	\N	123.75	\N	371.25
cmmcevito000304jllo5wsns4	RPM-MMCEVITM-HPIV	Guy Shotton	charlieman798@gmail.com	\N	our-brokers	Our Recommended Brokers	495.00	STRIPE	PENDING	cs_live_b1Y8mgNSPiShaXRHgyiqHhk93uXtbPVkEMJNFDyuX3BWf8acbMh8CFxLE9	\N	PENDING	2026-03-04 19:10:00.972	2026-03-04 19:10:02.563	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: Payout; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payout" (id, "affiliateId", amount, method, reference, status, notes, "createdAt", "processedAt") FROM stdin;
\.


--
-- Data for Name: Referral; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Referral" (id, "affiliateId", "ipAddress", "userAgent", "landingPage", "orderId", converted, commission, "createdAt", "convertedAt") FROM stdin;
cmjfm0z3y000004l8pal2lsg6	cmjflxpj9000004l4h5pljlug	86.168.224.137	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	\N	f	\N	2025-12-21 10:54:24.19	\N
cmkh9no6q000004l46s32ycis	cmk5sjfp8000004jme9stvja1	92.247.172.111	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	/	\N	f	\N	2026-01-16 19:23:22.802	\N
cmksg8nbe000004l5y1ghkb68	cmk5sjfp8000004jme9stvja1	91.172.184.67	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	/	\N	f	\N	2026-01-24 15:13:07.082	\N
cmksh2fwl000004l59tx288s0	cmk5sjfp8000004jme9stvja1	45.144.227.69	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	/	\N	f	\N	2026-01-24 15:36:17.157	\N
cmlvbmxt3000004l71le25jb4	cmk5sjfp8000004jme9stvja1	78.210.173.132	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36	/	\N	f	\N	2026-02-20 20:07:16.647	\N
cmma438je000004ietpqadvab	cmk5sjfp8000004jme9stvja1	189.174.179.24	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0	/	\N	f	\N	2026-03-03 04:32:32.762	\N
cmmk8gw96000004js3pw9qd4t	cmk5sjfp8000004jme9stvja1	109.247.69.194	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-10 06:32:50.25	\N
cmmmky6xo000004jvaa8kvsbr	cmk5sjfp8000004jme9stvja1	87.67.61.58	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36	/	\N	f	\N	2026-03-11 21:57:44.988	\N
cmmpik1hz000004jr5w4dw6kz	cmk5sjfp8000004jme9stvja1	85.167.153.53	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-13 23:14:04.055	\N
cmmujg3vm000004jv4fp75o5e	cmk5sjfp8000004jme9stvja1	85.167.153.53	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-17 11:37:51.01	\N
cmmuta077000004jy8h23tp14	cmk5sjfp8000004jme9stvja1	84.191.240.124	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-17 16:13:02.467	\N
cmmyys67c000004jyb5gpydla	cmk5sjfp8000004jme9stvja1	37.185.178.82	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36	/	\N	f	\N	2026-03-20 13:58:12.84	\N
cmmzxdo8x000004k0krdq1q92	cmk5sjfp8000004jme9stvja1	99.228.142.48	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-21 06:06:42.945	\N
cmn0fgzmr000004ju50zb62w9	cmk5sjfp8000004jme9stvja1	109.199.127.22	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-21 14:33:10.754	\N
cmn1yzmb4000004johkzb8ojf	cmk5sjfp8000004jme9stvja1	157.100.142.149	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-22 16:27:18.831	\N
cmn2tqq73000004juu6vv6jm2	cmk5sjfp8000004jme9stvja1	217.165.123.136	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-23 06:48:12.062	\N
cmn3kfrne000004k13l5bhnyk	cmk5sjfp8000004jme9stvja1	87.67.61.58	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36	/	\N	f	\N	2026-03-23 19:15:30.362	\N
cmn43mmdw000004jy9ozcggh9	cmk5sjfp8000004jme9stvja1	87.200.148.69	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-24 04:12:42.836	\N
cmn55asxc000004jowutdlsw4	cmk5sjfp8000004jme9stvja1	51.179.202.35	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	/	\N	f	\N	2026-03-24 21:47:16.848	\N
cmn7p4s47000004leavuqnn45	cmk5sjfp8000004jme9stvja1	94.31.110.232	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0	/	\N	f	\N	2026-03-26 16:38:00.535	\N
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
6d72dc11-9e74-4823-8b48-05823525044d	0873b3b3d1306164f8421ca394219bd7021d23a7f1be2fd2d1ab59cd71726249	2025-12-19 16:27:39.434003+00	20251219123557_init	\N	\N	2025-12-19 16:27:39.375015+00	1
4f57db81-10c4-4a38-bc2d-9e2c1996395c	557c9cb0ae4a87b080bedd94670340b2bb80d21e148e3854f23482ae20fd8611	2025-12-19 16:27:39.493194+00	20251219132031_add_stripe_receipt_url	\N	\N	2025-12-19 16:27:39.449952+00	1
\.


--
-- Name: AdminUser AdminUser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AdminUser"
    ADD CONSTRAINT "AdminUser_pkey" PRIMARY KEY (id);


--
-- Name: Affiliate Affiliate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Affiliate"
    ADD CONSTRAINT "Affiliate_pkey" PRIMARY KEY (id);


--
-- Name: BlogCategory BlogCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlogCategory"
    ADD CONSTRAINT "BlogCategory_pkey" PRIMARY KEY (id);


--
-- Name: BlogPost BlogPost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlogPost"
    ADD CONSTRAINT "BlogPost_pkey" PRIMARY KEY (id);


--
-- Name: ContactSubmission ContactSubmission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ContactSubmission"
    ADD CONSTRAINT "ContactSubmission_pkey" PRIMARY KEY (id);


--
-- Name: Coupon Coupon_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Coupon"
    ADD CONSTRAINT "Coupon_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: Payout Payout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payout"
    ADD CONSTRAINT "Payout_pkey" PRIMARY KEY (id);


--
-- Name: Referral Referral_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Referral"
    ADD CONSTRAINT "Referral_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AdminUser_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AdminUser_email_key" ON public."AdminUser" USING btree (email);


--
-- Name: Affiliate_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Affiliate_email_key" ON public."Affiliate" USING btree (email);


--
-- Name: Affiliate_referralCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Affiliate_referralCode_key" ON public."Affiliate" USING btree ("referralCode");


--
-- Name: Affiliate_resetToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Affiliate_resetToken_key" ON public."Affiliate" USING btree ("resetToken");


--
-- Name: BlogCategory_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "BlogCategory_slug_key" ON public."BlogCategory" USING btree (slug);


--
-- Name: BlogPost_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "BlogPost_slug_key" ON public."BlogPost" USING btree (slug);


--
-- Name: Coupon_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Coupon_code_key" ON public."Coupon" USING btree (code);


--
-- Name: Order_orderRef_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Order_orderRef_key" ON public."Order" USING btree ("orderRef");


--
-- Name: Referral_orderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Referral_orderId_key" ON public."Referral" USING btree ("orderId");


--
-- Name: BlogPost BlogPost_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BlogPost"
    ADD CONSTRAINT "BlogPost_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."BlogCategory"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payout Payout_affiliateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payout"
    ADD CONSTRAINT "Payout_affiliateId_fkey" FOREIGN KEY ("affiliateId") REFERENCES public."Affiliate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Referral Referral_affiliateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Referral"
    ADD CONSTRAINT "Referral_affiliateId_fkey" FOREIGN KEY ("affiliateId") REFERENCES public."Affiliate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Referral Referral_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Referral"
    ADD CONSTRAINT "Referral_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict jusA3oDLIhCBv0zg6lkjYSz3cipvyUNlOfUzCJdFkzGvKEf1O6LmuA0DwlAY0Lt

