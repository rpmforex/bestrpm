# rpmforex.com: handover pack

Everything needed to run rpmforex.com on your own hosting. Prepared 11 October 2026.

## What's in this pack

| File | What it is |
|---|---|
| `rpmforex-site-code.zip` | The full website source code (latest live version) |
| `database/rpmforex.dump` | Full database backup (PostgreSQL custom format, for `pg_restore`) |
| `database/rpmforex.sql` | The same backup as plain SQL (for `psql`) |
| `blob-images/blog/` | The 3 images uploaded through the blog admin |
| `HANDOVER-README.md` | This guide |

## What the site is

- **Framework:** Next.js 16 (React), TypeScript, Tailwind CSS.
- **Database:** PostgreSQL 17, accessed with Prisma (schema and migrations in `prisma/`).
- **Built for:** Vercel (it will run on any Node.js host, but Vercel is the simplest).
- **Features:** marketing pages, blog with admin, contact form (Cloudflare Turnstile spam check + email via Resend), Stripe checkout and orders, coupons, an affiliate/referral system with payouts, and an admin area.
- **Database contents (10 tables):** 3 admin users, 5 affiliates, 20 referrals, 3 orders, 2 coupons, 3 blog posts, 2 blog categories, 2 contact submissions, 0 payouts, plus Prisma's migration record. Admin passwords are stored hashed; existing admin logins keep working after the restore.

## Setting it up on your own Vercel account

1. **Code:** create a GitHub repository, unzip `rpmforex-site-code.zip` into it and push. In Vercel: Add New → Project → import that repository.
2. **Database:** in the Vercel project, Storage → Create → Neon (Postgres). This adds `DATABASE_URL` and related settings automatically. Restore the backup into it:
   `pg_restore --no-owner --no-privileges -d "<DATABASE_URL_UNPOOLED>" database/rpmforex.dump`
   (or `psql "<DATABASE_URL_UNPOOLED>" -f database/rpmforex.sql`). Use PostgreSQL 17+ tools.
3. **Images:** in the Vercel project, Storage → Create → Blob. Upload the 3 files in `blob-images/blog/`, then update the three `BlogPost.featuredImage` values in the database to the new image addresses (the old ones point at our storage, which will be switched off).
4. **Settings (Environment Variables):** add these in Vercel → Settings → Environment Variables. None of our values are included: each one should be your own.

| Setting | What to put |
|---|---|
| `DATABASE_URL`, `DATABASE_URL_UNPOOLED` | Added automatically by step 2 |
| `BLOB_READ_WRITE_TOKEN` | Added automatically by step 3 |
| `NEXT_PUBLIC_BASE_URL` | `https://rpmforex.com` |
| `ADMIN_JWT_SECRET`, `AFFILIATE_JWT_SECRET` | New long random strings (e.g. `openssl rand -hex 32`). Changing these just signs everyone out once |
| `STRIPE_SECRET_KEY`, `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | From your Stripe dashboard → Developers → API keys |
| `STRIPE_WEBHOOK_SECRET` | In Stripe → Developers → Webhooks, add an endpoint `https://rpmforex.com/api/stripe/webhook`; copy its signing secret |
| `RESEND_API_KEY`, `CONTACT_EMAIL` | A Resend account (resend.com) with rpmforex.com verified (it gives you DNS records to add); `CONTACT_EMAIL` = where contact-form enquiries should go |
| `NEXT_PUBLIC_TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY` | A Cloudflare Turnstile widget (free) listing both `rpmforex.com` and `www.rpmforex.com` |
| `KV_REST_API_URL`, `KV_REST_API_TOKEN` (or `UPSTASH_REDIS_REST_URL` / `_TOKEN`) | Vercel → Storage → Upstash Redis (free tier). Used for rate-limiting the forms |
| `CSP_REPORT_ONLY` | Optional; leave unset |

5. **Deploy**, check the site on its `.vercel.app` address (home page, blog, contact form, admin login, a test checkout in Stripe test mode).
6. **Domain:** in your Vercel project, Settings → Domains → add `rpmforex.com` and `www.rpmforex.com`, then update your DNS to the records Vercel shows. Tell us when you're ready and we'll release the domain from our side at the same time, so there's no downtime.

## After the switch

Once your copy is live on the domain we'll remove our copy and its database. Keep this pack somewhere safe as your backup.
